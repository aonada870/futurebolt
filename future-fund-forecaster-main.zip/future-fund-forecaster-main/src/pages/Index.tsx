import { InvestmentCalculator } from "@/components/InvestmentCalculator";

const Index = () => {
  return <InvestmentCalculator />;
};

export default Index;